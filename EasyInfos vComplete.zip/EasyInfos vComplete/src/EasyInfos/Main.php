<?php

namespace EasyInfos;

use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\Server;
use pocketmine\scheduler\CallbackTask;
use \pocketmine\utils\TextFormat as Color;
use pocketmine\Player;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\tile\Sign;

class Main extends PluginBase implements Listener {
    
    public $prefix = "§7[§6EasyInfos§7] ";


    public function onEnable(){
        
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        
                
        $this->getLogger()->info(Color::GREEN."developed by GrowPixel!");
        
        @mkdir($this->getDataFolder());
                     $this->yml = new Config($this->getDataFolder()."config.yml",Config::YAML, array(
            			#developed by GrowPixel
            			
			));
			$this->yml = new Config($this->getDataFolder()."config.yml",Config::YAML, array(
            			"Info_Line1" => "- Message_1"
            			
			));
                        $this->yml = new Config($this->getDataFolder()."config.yml",Config::YAML, array(
            			"Info_Line2" => "- Message_2"
            			
			));
                        $this->yml = new Config($this->getDataFolder()."config.yml",Config::YAML, array(
            			"Info_Line3" => "- Message_3"
            			
			));
                        $this->yml = new Config($this->getDataFolder()."config.yml",Config::YAML, array(
            			"Info_Line4" => "- Message_4"
            			
			));
                        $this->yml = new Config($this->getDataFolder()."config.yml",Config::YAML, array(
            			"Info_Line5" => "- Message_5"
            			
			));
                        $this->yml = new Config($this->getDataFolder()."config.yml",Config::YAML, array(
            			"Info_Line6" => "- Message_5"
            			
			));
                        $this->yml = new Config($this->getDataFolder()."config.yml",Config::YAML, array(
            			"Info_Line7" => "- Message_5"
            			
			));
                        $this->yml = new Config($this->getDataFolder()."config.yml",Config::YAML, array(
            			"Info_Line8" => "- Message_5"
            			
			));
                        $this->yml = new Config($this->getDataFolder()."config.yml",Config::YAML, array(
            			"Info_Line9" => "- Message_5"
            			
			));
            		
    			$this->saveResource("config.yml");
    }
           public function onSignCreate(SignChangeEvent $event) {
           foreach ($this->getServer()->getOnlinePlayers() as $players){
               $Full = $this->getServer()->getMaxPlayers();
               $Online = count(Server::getInstance()->getOnlinePlayers);
           }
           $player = $event->getPlayer();
           $prefix = "§7[§6EasyInfos§7] ";
           
           if($event->getLine(0) == "info"){
               $player->sendMessage("$prefix"."Plz Read The Info!");
               
               $event->setLine(0, "$prefix");
               $event->setLine(1, Color::GRAY."§lStatus");
               $event->setLine(2, Color::GREEN."Online§7:");
               $event->setLine(3, Color::GREEN."$Online"."§7/§c"."$Full");
               
           }
       }

public function onCommand(CommandSender $sender, Command $cmd, $label, array $args) {


           
           
           if($cmd->getName() == "info"){
               
           
               
           $message_1 = $this->yml->get("Info_Line1");
           $message_2 = $this->yml->get("Info_Line2");
           $message_3 = $this->yml->get("Info_Line3");
           $message_4 = $this->yml->get("Info_Line4");
           $message_5 = $this->yml->get("Info_Line5");
           $message_6 = $this->yml->get("Info_Line6");
           $message_7 = $this->yml->get("Info_Line7");
           $message_8 = $this->yml->get("Info_Line8");
           $message_9 = $this->yml->get("Info_Line9");
           
         
               if(!isset($args[0])){
                       $sender->sendMessage(Color::GRAY."====================== §6Server Info§7 ======================");
                       $sender->sendMessage(Color::GREEN."$message_1");
                       $sender->sendMessage(Color::GREEN."$message_2");
                       $sender->sendMessage(Color::GREEN."$message_3");
                       $sender->sendMessage(Color::GREEN."$message_4");
                       $sender->sendMessage(Color::GREEN."$message_5");
                       $sender->sendMessage(Color::GREEN."$message_6");
                       $sender->sendMessage(Color::GREEN."$message_7");
                       $sender->sendMessage(Color::GREEN."$message_8");
                       $sender->sendMessage(Color::GREEN."$message_9");
                       $sender->sendMessage(Color::GRAY."====================== §6Server Info§7 ======================");
               }
               
               else {
                   if($args[0] == "info"){
                       $sender->sendMessage(Color::GRAY."====================== §6Server Info§7 ======================");
                       $sender->sendMessage(Color::GREEN."$message_1");
                       $sender->sendMessage(Color::GREEN."$message_2");
                       $sender->sendMessage(Color::GREEN."$message_3");
                       $sender->sendMessage(Color::GREEN."$message_4");
                       $sender->sendMessage(Color::GREEN."$message_5");
                       $sender->sendMessage(Color::GREEN."$message_6");
                       $sender->sendMessage(Color::GREEN."$message_7");
                       $sender->sendMessage(Color::GREEN."$message_8");
                       $sender->sendMessage(Color::GREEN."$message_9");
                       $sender->sendMessage(Color::GRAY."====================== §6Server Info§7 ======================");
                   }
               }
           }
}
}
               
